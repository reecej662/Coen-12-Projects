void pack(char *infile, char *outfile, struct tree *leaves[257]);
